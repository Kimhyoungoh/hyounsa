package com.example.myapplication2222;

public class Glide {
    public static System with(MainActivity mainActivity) {
        return null;
    }
}
